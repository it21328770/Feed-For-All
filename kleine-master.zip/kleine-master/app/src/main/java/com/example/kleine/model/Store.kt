package com.example.kleine.model

data class Store(
    val name:String,
    val uid:String
){
    constructor():this("","")
}
